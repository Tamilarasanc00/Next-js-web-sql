import { NextResponse } from "next/server";
import { Database } from "@/lib/db";
import { inventories, products } from "@/lib/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: Request, context: any) {
  const { id } = await context.params;

  const rows = await Database
    .select({
      invId: inventories.id,
      sku: inventories.sku,
      quantity: inventories.quantity,
      pointsEarned: inventories.pointsEarned,
      createdAt: inventories.createdAt,
      imageUrl: products.imageUrl,   // 👈 FIX: map correct product image
    })
    .from(inventories)
    .leftJoin(products, eq(products.sku, inventories.sku))
    .where(eq(inventories.userId, Number(id)));

  return NextResponse.json(rows);
}
