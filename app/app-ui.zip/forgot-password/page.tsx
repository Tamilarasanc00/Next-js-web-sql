"use client";

import { useState } from "react";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const res = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "Something went wrong");
      } else {
        setOtp(data.otp); // Display OTP to user (static flow)
        localStorage.setItem("resetEmail", email);
      }
    } catch {
      setError("Network error");
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-5">
      <form
        onSubmit={handleSubmit}
        className="bg-white shadow-lg p-6 rounded-md max-w-sm w-full space-y-4"
      >
        <h1 className="text-2xl font-bold text-center">Forgot Password</h1>

        {error && <p className="text-red-600 text-sm">{error}</p>}
        {otp && (
          <p className="text-green-600 text-sm">
            Your OTP is: <b>{otp}</b>
          </p>
        )}

        <input
          type="email"
          placeholder="Enter email"
          className="w-full p-2 border rounded"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <button
          disabled={loading}
          className="w-full bg-indigo-600 text-white p-2 rounded"
        >
          {loading ? "Sending OTP..." : "Send OTP"}
        </button>

        {otp && (
          <a
            href="/verify-otp"
            className="block text-center text-indigo-600 underline text-sm"
          >
            Enter OTP
          </a>
        )}
      </form>
    </div>
  );
}
