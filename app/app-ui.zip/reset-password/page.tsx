"use client";

import { useState } from "react";

export default function ResetPasswordPage() {
  const [newPassword, setNewPassword] = useState("");
  const [message, setMessage] = useState("");

  const email = typeof window !== "undefined" ? localStorage.getItem("resetEmail") : "";

  const handleSubmit = async (e: any) => {
    e.preventDefault();

    const res = await fetch("/api/auth/reset-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, newPassword }),
    });

    const data = await res.json();

    if (!res.ok) {
      setMessage("Error resetting password");
      return;
    }

    // setMessage("Password reset successfully! Redirecting...");
    // localStorage.removeItem("resetEmail");

    // setTimeout(() => (window.location.href = "/login"), 1500);

setMessage("Password reset successfully! Redirecting...");
localStorage.removeItem("resetEmail");

setTimeout(() => (window.location.href = "/reset-password/success"), 1500);




  };

  if (!email) return <p className="text-center mt-10">No email found. Please start over.</p>;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-5">
      <form
        onSubmit={handleSubmit}
        className="bg-white shadow-lg p-6 rounded-md max-w-sm w-full space-y-4"
      >
        <h1 className="text-2xl font-bold text-center">Reset Password</h1>

        {message && <p className="text-green-600 text-sm">{message}</p>}

        <input
          type="password"
          placeholder="Enter new password"
          className="w-full p-2 border rounded"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          required
        />

        <button className="w-full bg-indigo-600 text-white p-2 rounded">
          Update Password
        </button>
      </form>
    </div>
  );
}
