'use client'

import RegisterForm from "@/components/Auth/RegisterForm";

export default function RegisterPage() {
  return <RegisterForm onToggleMode={()=> {}}/>;
}
