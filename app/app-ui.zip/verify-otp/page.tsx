"use client";

import { useState } from "react";

export default function VerifyOtpPage() {
  const [otp, setOtp] = useState("");
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [resendLoading, setResendLoading] = useState(false);

  const email =
    typeof window !== "undefined" ? localStorage.getItem("resetEmail") : "";

  const handleSubmit = async (e: any) => {
    e.preventDefault();

    const res = await fetch("/api/auth/verify-otp", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, otp }),
    });

    const data = await res.json();

    if (!res.ok) {
      setError(data.error || "Invalid OTP");
      setMessage("");
      return;
    }

    window.location.href = "/reset-password";
  };

  const resendOtp = async () => {
    setResendLoading(true);
    setError("");
    setMessage("");

    try {
      const res = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      const data = await res.json();

      if (res.ok) {
        setMessage(`New OTP sent: ${data.otp}`);
      } else {
        setError(data.error || "Could not resend OTP");
      }
    } catch {
      setError("Network error");
    }

    setTimeout(() => setResendLoading(false), 3000); // 🟢 Prevent spam
  };

  if (!email)
    return <p className="text-center mt-10">No email found. Please start over.</p>;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-5">
      <form
        onSubmit={handleSubmit}
        className="bg-white shadow-lg p-6 rounded-md max-w-sm w-full space-y-4"
      >
        <h1 className="text-2xl font-bold text-center">Verify OTP</h1>

        {error && <p className="text-red-600 text-sm">{error}</p>}
        {message && <p className="text-green-600 text-sm">{message}</p>}

        <input
          type="number"
          placeholder="Enter 4-digit OTP"
          className="w-full p-2 border rounded"
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
          maxLength={4}
          required
        />

        <button className="w-full bg-indigo-600 text-white p-2 rounded">
          Verify OTP
        </button>

        <button
          type="button"
          onClick={resendOtp}
          disabled={resendLoading}
          className="w-full bg-gray-200 text-gray-800 mt-2 p-2 rounded hover:bg-gray-300 transition disabled:opacity-50"
        >
          {resendLoading ? "Sending..." : "Resend OTP"}
        </button>
      </form>
    </div>
  );
}
